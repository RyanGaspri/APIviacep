package br.com.local.myappviacepapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    Button btnBuscarCep;
    EditText txtCep;
    LinearLayout lblResposta;
    TextView RespostaCEP, RespostaLogradouro, RespostaUf, RespostaBairro, RespostaCidade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCep = findViewById(R.id.txtCep);
        btnBuscarCep = findViewById(R.id.btnBuscaCep);
        RespostaBairro = findViewById(R.id.cBairro);
        RespostaCEP = findViewById(R.id.cCep);
        RespostaCidade = findViewById(R.id.cCidade);
        RespostaLogradouro = findViewById(R.id.cLogradouro);
        RespostaUf = findViewById(R.id.cUF);
        lblResposta = findViewById(R.id.lblresposta);


        btnBuscarCep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // String endereco = txtCep.getText().toString().trim();

                try {
                    //preencher o cep no lblResposta do layout
                    CEP retorno = new HttpService(txtCep.getText().toString().trim()).execute().get();

                    lblResposta.getTextAlignment();
                    RespostaCEP.setText(retorno.getCep());
                    RespostaUf.setText(retorno.getUf());
                    RespostaCidade.setText(retorno.getLocalidade());
                    RespostaBairro.setText(retorno.getBairro());
                    RespostaLogradouro.setText(retorno.getLogradouro());

                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });

    }
}